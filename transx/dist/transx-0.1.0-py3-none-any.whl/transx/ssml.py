def from_vtt(vtt_file):
    pass