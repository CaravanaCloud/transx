from .cmd import cli


def main():
    cli(obj={})


if __name__ == "__main__":
    main()
