import click
from .utils import version
from .cmd import *


@cli.command('version')
@click.pass_context
def print_version(ctx):
    result = str({
        'version': version(),
        'context': ctx
    })
    click.echo(result)

